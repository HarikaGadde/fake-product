import styled from "styled-components";

const StyledButton = styled.button`
  background-color: #87ceeb;
  padding: 1rem 2rem;
  color: whitesmoke;
  border: none;

  &:hover {
    cursor: pointer;
  }
`;

function Button() {
  return (
    <div>
      <StyledButton>Start the camera</StyledButton>
    </div>
  );
}

export default Button;
