import { NavLink } from "react-router-dom";
import styled from "styled-components";

const Nav = styled.nav`
  background-color: black;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0rem 2rem;
`;

const Styledheading = styled.h3`
  color: white;
`;

const StyledNavLink = styled(NavLink)`
  text-decoration: none;
  color: white;
  margin-right: 1rem;
  &:hover,
  &:active,
  &.active:link,
  &.active:visited {
    color: cyan;
  }
`;

function Navbar() {
  return (
    <Nav>
      <Styledheading>Fake Product identification System</Styledheading>
      <div>
        <StyledNavLink to="/about">About</StyledNavLink>
        <StyledNavLink to="/instructions">Instructions</StyledNavLink>
        <StyledNavLink to="/login">Login</StyledNavLink>
        <StyledNavLink to="/register">Register</StyledNavLink>
      </div>
    </Nav>
  );
}

export default Navbar;
