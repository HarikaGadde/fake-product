function Instructions() {
  return (
    <div>
      <h1>Instructions page</h1>
    </div>
  );
}

export default Instructions;
