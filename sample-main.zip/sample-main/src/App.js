import { BrowserRouter, Route, Routes } from "react-router-dom";

import HomePage from "./HomePage";
import About from "./About";
import Instructions from "./Instructions";
import Register from "./Register";
import Login from "./Login";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route index element={<HomePage />}></Route>
        <Route path="about" element={<About />}></Route>
        <Route path="instructions" element={<Instructions />}></Route>
        <Route path="register" element={<Register />}></Route>
        <Route path="login" element={<Login />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
