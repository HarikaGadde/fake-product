import styled from "styled-components";
import Button from "./Button";

const StyledWrapper = styled.div`
  display: flex;
  justify-content: space-around;
  margin-top: 5rem;
`;

const StyledContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 2rem;
`;

const StyledImage = styled.img`
  width: 20rem;
  height: 15rem;
`;

function Main() {
  return (
    <StyledWrapper>
      <StyledContent>
        <h3>Start the camera and scan the QR code!!</h3>
        <Button />
      </StyledContent>
      <StyledImage
        src={`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEENGejkNAsB8zgVxHyjZH6OL-PcJsD3QPBzMlHISNaNcQhCbtQUXELDbjkukuEjPhYYw&usqp=CAU`}
      ></StyledImage>
    </StyledWrapper>
  );
}

export default Main;
