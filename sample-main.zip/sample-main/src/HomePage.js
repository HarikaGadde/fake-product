import styled from "styled-components";
import Main from "./Main";
import Navbar from "./Navbar";

const Layout = styled.div`
  margin: 0;
  padding: 0;
`;

function HomePage() {
  return (
    <Layout>
      <Navbar />
      <Main />
    </Layout>
  );
}

export default HomePage;
